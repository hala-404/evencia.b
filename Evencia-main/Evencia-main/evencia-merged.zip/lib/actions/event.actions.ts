'use server'

import { revalidatePath } from 'next/cache'
import { eq, and, ne, ilike, desc, count } from 'drizzle-orm'

import { connectToDatabase } from '@/lib/database'
import { events, users, eventCategories } from '@/lib/database/schema'
import { handleError } from '@/lib/utils'

import {
  CreateEventParams,
  UpdateEventParams,
  DeleteEventParams,
  GetAllEventsParams,
  GetEventsByUserParams,
  GetRelatedEventsByCategoryParams,
} from '@/types'

const getCategoryByName = async (name: string, db: any) => {
  const [category] = await db.select().from(eventCategories).where(ilike(eventCategories.name, `%${name}%`))
  return category
}

// CREATE
export async function createEvent({ userId, event, path }: CreateEventParams) {
  try {
    const db = await connectToDatabase()

    const [organizer] = await db.select().from(users).where(eq(users.userId, parseInt(userId)))
    if (!organizer) throw new Error('Organizer not found')

    const [newEvent] = await db.insert(events).values({
      title: event.title,
      description: event.description,
      categoryId: parseInt(event.categoryId),
      createdBy: parseInt(userId),
      imageUrl: event.imageUrl,
      price: event.price,
      isFree: event.isFree ? 'true' : 'false',
      url: event.url,
    }).returning()
    
    revalidatePath(path)

    return JSON.parse(JSON.stringify(newEvent))
  } catch (error) {
    handleError(error)
  }
}

// GET ONE EVENT BY ID
export async function getEventById(eventId: string) {
  try {
    const db = await connectToDatabase()

    const [event] = await db.select({
      eventId: events.eventId,
      title: events.title,
      description: events.description,
      categoryId: events.categoryId,
      categoryName: eventCategories.name,
      createdBy: events.createdBy,
      organizerFirstName: users.firstName,
      organizerLastName: users.lastName,
      imageUrl: events.imageUrl,
      price: events.price,
      isFree: events.isFree,
      url: events.url,
      createdAt: events.createdAt,
      updatedAt: events.updatedAt,
    })
    .from(events)
    .leftJoin(users, eq(events.createdBy, users.userId))
    .leftJoin(eventCategories, eq(events.categoryId, eventCategories.categoryId))
    .where(eq(events.eventId, parseInt(eventId)))

    if (!event) throw new Error('Event not found')

    return JSON.parse(JSON.stringify(event))
  } catch (error) {
    handleError(error)
  }
}

// UPDATE
export async function updateEvent({ userId, event, path }: UpdateEventParams) {
  try {
    const db = await connectToDatabase()

    const [eventToUpdate] = await db.select().from(events).where(eq(events.eventId, parseInt(event._id)))
    if (!eventToUpdate || eventToUpdate.createdBy !== parseInt(userId)) {
      throw new Error('Unauthorized or event not found')
    }

    const [updatedEvent] = await db.update(events)
      .set({
        title: event.title,
        description: event.description,
        categoryId: parseInt(event.categoryId),
        imageUrl: event.imageUrl,
        price: event.price,
        isFree: event.isFree ? 'true' : 'false',
        url: event.url,
        updatedAt: new Date(),
      })
      .where(eq(events.eventId, parseInt(event._id)))
      .returning()
    
    revalidatePath(path)

    return JSON.parse(JSON.stringify(updatedEvent))
  } catch (error) {
    handleError(error)
  }
}

// DELETE
export async function deleteEvent({ eventId, path }: DeleteEventParams) {
  try {
    const db = await connectToDatabase()

    await db.delete(events).where(eq(events.eventId, parseInt(eventId)))
    revalidatePath(path)
  } catch (error) {
    handleError(error)
  }
}

// GET ALL EVENTS
export async function getAllEvents({ query, limit = 6, page, category }: GetAllEventsParams) {
  try {
    const db = await connectToDatabase()

    let conditions = []
    
    if (query) {
      conditions.push(ilike(events.title, `%${query}%`))
    }
    
    if (category) {
      const categoryObj = await getCategoryByName(category, db)
      if (categoryObj) {
        conditions.push(eq(events.categoryId, categoryObj.categoryId))
      }
    }

    const skipAmount = (Number(page) - 1) * limit
    
    const eventsQuery = db.select({
      eventId: events.eventId,
      title: events.title,
      description: events.description,
      categoryId: events.categoryId,
      categoryName: eventCategories.name,
      createdBy: events.createdBy,
      organizerFirstName: users.firstName,
      organizerLastName: users.lastName,
      imageUrl: events.imageUrl,
      price: events.price,
      isFree: events.isFree,
      url: events.url,
      createdAt: events.createdAt,
      updatedAt: events.updatedAt,
    })
    .from(events)
    .leftJoin(users, eq(events.createdBy, users.userId))
    .leftJoin(eventCategories, eq(events.categoryId, eventCategories.categoryId))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(events.createdAt))
    .offset(skipAmount)
    .limit(limit)

    const eventsList = await eventsQuery
    
    const [eventsCount] = await db.select({ count: count() })
      .from(events)
      .where(conditions.length > 0 ? and(...conditions) : undefined)

    return {
      data: JSON.parse(JSON.stringify(eventsList)),
      totalPages: Math.ceil(eventsCount.count / limit),
    }
  } catch (error) {
    handleError(error)
  }
}

// GET EVENTS BY ORGANIZER
export async function getEventsByUser({ userId, limit = 6, page }: GetEventsByUserParams) {
  try {
    const db = await connectToDatabase()

    const skipAmount = (page - 1) * limit

    const eventsQuery = db.select({
      eventId: events.eventId,
      title: events.title,
      description: events.description,
      categoryId: events.categoryId,
      categoryName: eventCategories.name,
      createdBy: events.createdBy,
      organizerFirstName: users.firstName,
      organizerLastName: users.lastName,
      imageUrl: events.imageUrl,
      price: events.price,
      isFree: events.isFree,
      url: events.url,
      createdAt: events.createdAt,
      updatedAt: events.updatedAt,
    })
    .from(events)
    .leftJoin(users, eq(events.createdBy, users.userId))
    .leftJoin(eventCategories, eq(events.categoryId, eventCategories.categoryId))
    .where(eq(events.createdBy, parseInt(userId)))
    .orderBy(desc(events.createdAt))
    .offset(skipAmount)
    .limit(limit)

    const eventsList = await eventsQuery
    
    const [eventsCount] = await db.select({ count: count() })
      .from(events)
      .where(eq(events.createdBy, parseInt(userId)))

    return { 
      data: JSON.parse(JSON.stringify(eventsList)), 
      totalPages: Math.ceil(eventsCount.count / limit) 
    }
  } catch (error) {
    handleError(error)
  }
}

// GET RELATED EVENTS: EVENTS WITH SAME CATEGORY
export async function getRelatedEventsByCategory({
  categoryId,
  eventId,
  limit = 3,
  page = 1,
}: GetRelatedEventsByCategoryParams) {
  try {
    const db = await connectToDatabase()

    const skipAmount = (Number(page) - 1) * limit
    
    const eventsQuery = db.select({
      eventId: events.eventId,
      title: events.title,
      description: events.description,
      categoryId: events.categoryId,
      categoryName: eventCategories.name,
      createdBy: events.createdBy,
      organizerFirstName: users.firstName,
      organizerLastName: users.lastName,
      imageUrl: events.imageUrl,
      price: events.price,
      isFree: events.isFree,
      url: events.url,
      createdAt: events.createdAt,
      updatedAt: events.updatedAt,
    })
    .from(events)
    .leftJoin(users, eq(events.createdBy, users.userId))
    .leftJoin(eventCategories, eq(events.categoryId, eventCategories.categoryId))
    .where(and(
      eq(events.categoryId, parseInt(categoryId)),
      ne(events.eventId, parseInt(eventId))
    ))
    .orderBy(desc(events.createdAt))
    .offset(skipAmount)
    .limit(limit)

    const eventsList = await eventsQuery
    
    const [eventsCount] = await db.select({ count: count() })
      .from(events)
      .where(and(
        eq(events.categoryId, parseInt(categoryId)),
        ne(events.eventId, parseInt(eventId))
      ))

    return { 
      data: JSON.parse(JSON.stringify(eventsList)), 
      totalPages: Math.ceil(eventsCount.count / limit) 
    }
  } catch (error) {
    handleError(error)
  }
}

