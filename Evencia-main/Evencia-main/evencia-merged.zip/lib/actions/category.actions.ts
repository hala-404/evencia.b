"use server"

import { CreateCategoryParams } from "@/types"
import { handleError } from "../utils"
import { connectToDatabase } from "../database"
import { eventCategories } from "../database/schema"

export const createCategory = async ({ categoryName }: CreateCategoryParams) => {
  try {
    const db = await connectToDatabase();

    const [newCategory] = await db.insert(eventCategories).values({
      name: categoryName
    }).returning();

    return JSON.parse(JSON.stringify(newCategory));
  } catch (error) {
    handleError(error)
  }
}

export const getAllCategories = async () => {
  try {
    const db = await connectToDatabase();

    const categories = await db.select().from(eventCategories);

    return JSON.parse(JSON.stringify(categories));
  } catch (error) {
    handleError(error)
  }
}

