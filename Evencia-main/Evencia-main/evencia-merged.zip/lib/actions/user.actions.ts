'use server'

import { revalidatePath } from 'next/cache'
import { eq } from 'drizzle-orm'

import { connectToDatabase } from '@/lib/database'
import { users, events, registrations } from '@/lib/database/schema'
import { handleError } from '@/lib/utils'

import { CreateUserParams, UpdateUserParams } from '@/types'

export async function createUser(user: CreateUserParams) {
  try {
    const db = await connectToDatabase()

    const [newUser] = await db.insert(users).values({
      clerkId: user.clerkId,
      email: user.email,
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
      photo: user.photo,
    }).returning()
    
    return JSON.parse(JSON.stringify(newUser))
  } catch (error) {
    handleError(error)
  }
}

export async function getUserById(userId: string) {
  try {
    const db = await connectToDatabase()

    const [user] = await db.select().from(users).where(eq(users.userId, parseInt(userId)))

    if (!user) throw new Error('User not found')
    return JSON.parse(JSON.stringify(user))
  } catch (error) {
    handleError(error)
  }
}

export async function getUserByClerkId(clerkId: string) {
  try {
    const db = await connectToDatabase()

    const [user] = await db.select().from(users).where(eq(users.clerkId, clerkId))

    if (!user) throw new Error('User not found')
    return JSON.parse(JSON.stringify(user))
  } catch (error) {
    handleError(error)
  }
}

export async function updateUser(clerkId: string, user: UpdateUserParams) {
  try {
    const db = await connectToDatabase()

    const [updatedUser] = await db.update(users)
      .set({
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        photo: user.photo,
      })
      .where(eq(users.clerkId, clerkId))
      .returning()

    if (!updatedUser) throw new Error('User update failed')
    return JSON.parse(JSON.stringify(updatedUser))
  } catch (error) {
    handleError(error)
  }
}

export async function deleteUser(clerkId: string) {
  try {
    const db = await connectToDatabase()

    // Find user to delete
    const [userToDelete] = await db.select().from(users).where(eq(users.clerkId, clerkId))

    if (!userToDelete) {
      throw new Error('User not found')
    }

    // Delete related registrations first
    await db.delete(registrations).where(eq(registrations.userId, userToDelete.userId))

    // Delete user
    const [deletedUser] = await db.delete(users)
      .where(eq(users.clerkId, clerkId))
      .returning()
    
    revalidatePath('/')

    return deletedUser ? JSON.parse(JSON.stringify(deletedUser)) : null
  } catch (error) {
    handleError(error)
  }
}

